package exercise;

public class CloseException extends IllegalArgumentException {
	public CloseException() {
	}

}
