
package exercise;

public class Application {
  public static void main(String[] args) {
   IUApp iu = new IUApp();
   iu.Menu();
  }
}
